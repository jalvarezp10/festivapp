// Usuarios ficticios
let usersData = [
  { id: 1, name: "Usuario1", email: "usuario1@example.com" },
  { id: 2, name: "Usuario2", email: "usuario2@example.com" },
  { id: 3, name: "Usuario3", email: "usuario3@example.com" }
];

// Función para llenar la tabla con datos de usuarios
function fillUsersTable() {
  const usersTableBody = document.getElementById("usersTableBody");

  usersData.forEach(user => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${user.id}</td>
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td>
        <button class="admin-button" onclick="deleteUser(${user.id})">Eliminar</button>
      </td>
    `;
    usersTableBody.appendChild(row);
  });
}

// Función para simular la eliminación de un usuario
function deleteUser(userId) {
  console.log("ID del usuario a eliminar:", userId);
  
  // Filtrar el array para eliminar el usuario con el ID correspondiente
  usersData = usersData.filter(user => user.id !== userId);
  console.log("Usuarios después de la eliminación:", usersData);

  // Volver a llenar la tabla para reflejar los cambios
  const usersTableBody = document.getElementById("usersTableBody");
  usersTableBody.innerHTML = ""; // Limpiamos la tabla
  fillUsersTable(); // Llenamos la tabla nuevamente
}
// Función para agregar un nuevo usuario
function addUser() {
  // Obtener los datos del nuevo usuario del formulario
  const id = usersData.length + 1; // Generar un nuevo ID
  const name = document.getElementById("newUserName").value;
  const email = document.getElementById("newUserEmail").value;

  // Validar que se ingresen los datos requeridos
  if (!name || !email) {
    alert("Por favor ingrese el nombre y el correo electrónico del nuevo usuario.");
    return;
  }

  // Crear un objeto para el nuevo usuario
  const newUser = { id, name, email };

  // Agregar el nuevo usuario al array
  usersData.push(newUser);

  // Limpiar los campos del formulario
  document.getElementById("newUserName").value = "";
  document.getElementById("newUserEmail").value = "";

  // Volver a llenar la tabla para reflejar los cambios
  const usersTableBody = document.getElementById("usersTableBody");
  usersTableBody.innerHTML = ""; // Limpiamos la tabla
  fillUsersTable(); // Llenamos la tabla nuevamente
}
document.addEventListener("DOMContentLoaded", function() {
  const showAddUserFormBtn = document.getElementById("showAddUserFormBtn");
  const addUserForm = document.getElementById("addUserForm");

  showAddUserFormBtn.addEventListener("click", function() {
    addUserForm.style.display = "block";
  });
});
// Función para mostrar el formulario de agregar usuario y ocultar el botón
function showAddUserForm() {
  const addUserForm = document.getElementById("addUserForm");
  const showAddUserFormBtn = document.getElementById("showAddUserFormBtn");

  addUserForm.style.display = "block"; // Mostramos el formulario
  showAddUserFormBtn.style.display = "none"; // Ocultamos el botón "Añadir Usuario"
}

// Obtener referencia al botón "Añadir Usuario"
const showAddUserFormBtn = document.getElementById("showAddUserFormBtn");

// Agregar evento de clic al botón "Añadir Usuario"
showAddUserFormBtn.addEventListener("click", showAddUserForm);


// Llenar la tabla cuando la página se cargue
fillUsersTable();
